<html>
<head>
<title>CS 360</title>
<link rel="stylesheet" type="text/css" href="360.css">
<!--
<link rel="stylesheet" type="text/css" href="red.css">
-->
</head>

<!--
<style type="text/css">
body {
  color: red;
  background-color: yellow;
}
p {
  color: blue;
}
</style>
-->


<body>

<div id="banner">
<h1> Internet Programming </h1>
</div>
<div id="nav_menu">
<ul>
	<li><a href="contact.html"> Contact </a></li>	
	<li><a href="resume.html"> Resume </a></li>
	<li><a href="current.html"> Current Weather </a></li>
	<li><a href="forcast.html"> Weather Forecast</a>
</ul>
</div>

<div id="content">
<p>
Welcome to Web Programming!.
<ul>
<li> Hello
<li> Goodbye
</ul>

<pre>
This is text
main() {
  lskjdlj
}
</pre>

<form>
First name:<br>
<input type="text" name="firstname">
<br>
Last name:<br>
<input type="text" name="lastname">
</form>

<img src="clement.jpg">
</p>
</div>

</body>

</html>

